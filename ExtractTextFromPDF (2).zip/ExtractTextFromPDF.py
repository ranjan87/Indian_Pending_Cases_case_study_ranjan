from io import StringIO
from pdfminer.pdfinterp import PDFResourceManager, PDFPageInterpreter
from pdfminer.converter import TextConverter
from pdfminer.layout import LAParams
from pdfminer.pdfpage import PDFPage
import os
import mysql.connector


def convert(fname, pages=None):
    print("Current file: " + fname);
    if not pages:
        pagenums = set()
    else:
        pagenums = set(pages)

    output = StringIO()
    manager = PDFResourceManager()
    converter = TextConverter(manager, output, laparams=LAParams())
    interpreter = PDFPageInterpreter(manager, converter)

    infile = open(fname, 'rb')
    for page in PDFPage.get_pages(infile, pagenums):
        interpreter.process_page(page)
    infile.close()
    converter.close()
    text = output.getvalue()
    output.close

    config = {
        'user': 'wainsoho_bnjan',
        'password': 'neeranjan87',
        'host': 'wainsohost.com',
        'database': 'wainsoho_tu'
    }

    cnx = mysql.connector.connect(**config)
    cur = cnx.cursor(buffered=True)

    add_receipts = ("insert into tbl_receipts "
                    "(filename, data)"
                    "values(%s, %s)")
    data_receipts = (fname, text)

    cur.execute(add_receipts, data_receipts)
    cnx.commit()
    cur.close()
    cnx.close()

def convertMultiple(pdfDir):
    if pdfDir == "": pdfDir = os.getcwd() + "\\"
    for pdf in os.listdir(pdfDir):
        fileExtension = pdf.split(".")[-1]
        if fileExtension == "pdf":
            pdfFilename = pdfDir + pdf
            convert(pdfFilename)

pdfDir = "C:/user_temp/PDFParsing/"

convertMultiple(pdfDir)